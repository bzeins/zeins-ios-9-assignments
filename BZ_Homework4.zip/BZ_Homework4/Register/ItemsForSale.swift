//
//  ItemsForSale.swift
//  Register
//
//  Created by Barbara Zeins on 8/2/16.
//  Copyright © 2016 Barbara Zeins. All rights reserved.
//

import Foundation

class ForSale {
    
    let title: String
    let price: String
    
    init(title: String, price: String) {
        self.title = title
        self.price = price
        
    }
}
