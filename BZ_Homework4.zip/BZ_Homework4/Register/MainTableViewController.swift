//
//  MainTableViewController.swift
//  Register
//
//  Created by Barbara Zeins on 8/1/16.
//  Copyright © 2016 Barbara Zeins. All rights reserved.
//

import UIKit



class MainTableViewController: UITableViewController {
    
 //MARK Declaration
    
    private var itemsInCart = [ForSale]()
    


    override func viewDidLoad() {
        super.viewDidLoad()
        }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
           }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "InventorySegue" {
            if let navigationController = segue.destinationViewController as? UINavigationController {
                if let inventoryViewController = navigationController.topViewController as? InventoryViewController {
                    
            inventoryViewController.delegate = self
                }
            }
        }
        
        else if segue.identifier == "CheckoutSegue" {
            if let checkoutViewController = segue.destinationViewController as? CheckoutViewController {
               
                
         checkoutViewController.cartItems = itemsInCart
                
                                              
                
            }
        }
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsInCart.count
    }
    

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as? CustomCell
        
        let inventory = itemsInCart[indexPath.row]

        
        cell!.priceLabel?.text = inventory.price
        cell!.itemLabel?.text = inventory.title
        
        return cell!

      }
    
}

extension MainTableViewController: InventoryViewControllerDelegate {
    func didClickItem (inventory: ForSale) {
        itemsInCart.append(inventory)
        tableView.reloadData()
    }
}







    