//
//  CheckoutViewController.swift
//  Register
//
//  Created by Barbara Zeins on 8/1/16.
//  Copyright © 2016 Barbara Zeins. All rights reserved.
//

import UIKit





class CheckoutViewController: UIViewController {
    
//receiver variable
    
    var cartItems = [ForSale]()
    var billTotal:Float = 0.00
    var checkoutChange:Float = 0.00
    
 
   
  
    @IBOutlet weak var itemsPurchased: UILabel!
    
    @IBOutlet weak var totalAmount: UILabel!
    
    @IBOutlet weak var cashEntered: UITextField!
    


    @IBAction func checkoutButton(sender: AnyObject) {
    }
       
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for item in cartItems {
            
            billTotal = billTotal + Float(item.price)!

        }
        
        itemsPurchased.text = "You purchased \(cartItems.count) items"
        totalAmount.text = "Your bill comes to $\(billTotal)"
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "changesegue" {
            if let changeViewController = segue.destinationViewController as? ChangeViewController {
                let cash = Float(cashEntered.text!)
                checkoutChange = cash! - billTotal
                
               changeViewController.yourCash = checkoutChange
            }

        }
    }
    
}
    

