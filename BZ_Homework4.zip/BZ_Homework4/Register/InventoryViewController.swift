//
//  InventoryViewController.swift
//  Register
//
//  Created by Barbara Zeins on 8/1/16.
//  Copyright © 2016 Barbara Zeins. All rights reserved.
//

import UIKit

protocol InventoryViewControllerDelegate: class{
    func didClickItem(item: ForSale)
}

class InventoryViewController: UIViewController {
 
    var inventory = [ForSale]()
    weak var delegate: InventoryViewControllerDelegate?

    
    @IBAction func item1WasClicked(sender: AnyObject) {
        
        let item1: ForSale =  ForSale(title: "corn", price: "1.29")
        
        delegate?.didClickItem(item1)
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBAction func item2WasClicked(sender: AnyObject) {
    
    let item2: ForSale =  ForSale(title: "asparagus", price: "1.62")
    
    delegate?.didClickItem(item2)
    
    dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    @IBAction func item3WasClicked(sender: AnyObject) {
    
        let item3: ForSale =  ForSale(title: "beans", price: "2.39")
        
        delegate?.didClickItem(item3)
        
        dismissViewControllerAnimated(true, completion: nil)
    
    
    }
    
    @IBAction func item4WasClicked(sender: AnyObject) {
        
        let item4: ForSale =  ForSale(title: "eggplant", price: ".89")
        
        delegate?.didClickItem(item4)
        
        dismissViewControllerAnimated(true, completion: nil)

    
    
    }
    
    @IBAction func item5WasClicked(sender: AnyObject) {
        
        let item5: ForSale =  ForSale(title: "parsnips", price: ".79")
        
        delegate?.didClickItem(item5)
        
        dismissViewControllerAnimated(true, completion: nil)

        
}
    
    @IBAction func item6WasClicked(sender: AnyObject) {
        let item6: ForSale =  ForSale(title: "other green items", price: ".59")
        
        delegate?.didClickItem(item6)
        
        dismissViewControllerAnimated(true, completion: nil)

       
    
    }
    
    
    override func viewWillAppear(animated: Bool){
        super.viewWillAppear(animated)
    
//    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
}


