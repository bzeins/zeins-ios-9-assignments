//
//  ChangeViewController.swift
//  Register
//
//  Created by Barbara Zeins on 8/1/16.
//  Copyright © 2016 Barbara Zeins. All rights reserved.
//

import UIKit



class ChangeViewController: UIViewController {
    
       var yourCash:Float = 0.00
   

    
    
    @IBOutlet weak var change: UILabel!
    
    
        
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
       change.text = "$ \(yourCash)"
        
        

            }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

    
    }


